package com.intent.com.boundservice;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.provider.ContactsContract;
import android.provider.Telephony;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView textView;
    private EditText firstInputEt,secondInputEt;

    private boolean isBound = false;
    private MyBoundService myBoundService;

    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder iBinder) {
            MyBoundService.MyLocalBinder myLocalBinder = (MyBoundService.MyLocalBinder) iBinder;
           myBoundService= myLocalBinder.getMyBoundService();
            isBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            isBound = false;

        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.textViewID);
        firstInputEt = findViewById(R.id.firstInputID);
        secondInputEt = findViewById(R.id.secondInputID);
    }

    @Override
    protected void onStart() {
        super.onStart();
        Intent intent = new Intent(MainActivity.this,MyBoundService.class);
        bindService(intent,serviceConnection,BIND_AUTO_CREATE);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (isBound){
            unbindService(serviceConnection);
            isBound = false;
        }
    }

    public void addNumber(View view) {
        int firstValue = Integer.valueOf(firstInputEt.getText().toString());
        int secondValue = Integer.valueOf(secondInputEt.getText().toString());
        String result ="";
        if (isBound){
          result= String.valueOf(myBoundService.addition(firstValue,secondValue));
          textView.setText(result);
        }

    }

}
