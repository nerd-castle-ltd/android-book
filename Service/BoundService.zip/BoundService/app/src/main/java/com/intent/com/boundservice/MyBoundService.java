package com.intent.com.boundservice;

import android.app.Service;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Binder;
import android.os.IBinder;
import android.provider.CalendarContract;
import android.provider.ContactsContract;
import android.support.annotation.Nullable;
import android.support.v4.content.FileProvider;
import android.util.Log;

public class MyBoundService extends Service {

    private static String TAG = MyBoundService.class.getName();
    private MyLocalBinder myLocalBinder = new MyLocalBinder();
    public class MyLocalBinder extends Binder{

        MyBoundService getMyBoundService(){
            return MyBoundService.this;
        }

    }


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        Log.d(TAG, "onBind: Thread name" +Thread.currentThread().getName());
        return myLocalBinder;
    }

    public int addition(int a, int b ){

        return a+b;
    }

}
